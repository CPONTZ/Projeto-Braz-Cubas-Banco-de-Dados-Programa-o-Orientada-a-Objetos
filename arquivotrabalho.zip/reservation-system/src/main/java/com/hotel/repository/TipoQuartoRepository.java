package com.hotel.repository;

import com.hotel.model.TipoQuarto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoQuartoRepository extends JpaRepository<TipoQuarto, Long> {
}
